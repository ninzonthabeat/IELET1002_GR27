#pragma once

#include <Wire.h>
Zumo32U4IMU imu;
Zumo32U4ButtonB buttonB;

// ----- Globale variaber -----
uint32_t turnAngle = 0; // turnAngle representerer hvor langt roboten har snudd seg/rotert siden sist turnSensor ble resatt.
int16_t turnRate; // turnRate representerer hvor fort gyroen roterer, representert i en konstant * 0.07 grader per sekund.
int16_t gyroOffset; // gyroOffset representerer gjennomsnittsverdien avlest fra gyroen under kalibreringsfasen.
uint16_t gyroLastUpdate = 0;  // gyroLastUpdate sier noe om hvor lang tid det har gått imellom målinger.

// Resetter turnAngle til 0.
void turnSensorReset()
{
  gyroLastUpdate = micros();
  turnAngle = 0;
}

// Oppdaterer turnAngle.
void turnSensorUpdate()
{
  imu.readGyro(); //Leser gyroverdi.
  turnRate = imu.g.z - gyroOffset;

  // Dette sier noe om tid siden siste oppdatering.
  uint16_t m = micros();
  uint16_t dt = m - gyroLastUpdate;
  gyroLastUpdate = m;

  // dt * turnRate = hvor langt gyroen har rotert siden sist oppdatering.
  int32_t d = (int32_t)turnRate * dt;

  // The units of d are gyro digits times microseconds.  We need
  // to convert those to the units of turnAngle, where 2^29 units
  // represents 45 degrees.  The conversion from gyro digits to
  // degrees per second (dps) is determined by the sensitivity of
  // the gyro: 0.07 degrees per second per digit.
  //
  // (0.07 dps/digit) * (1/1000000 s/us) * (2^29/45 unit/degree)
  // = 14680064/17578125 unit/(digit*us)
  turnAngle += (int64_t)d * 14680064 / 17578125;
}

// Kalibrerer gyro, kalles i void setup()
void turnSensorSetup()
{
  Wire.begin();
  imu.init();
  imu.enableDefault();
  imu.configureForTurnSensing();

  // Lyser gul LED for å signalisere at kalibrering foregår
  ledYellow(1);

  // Venter 500ms for å fjerne fingrene fra knappen
  delay(500);

  // Kalibrering
  int32_t total = 0;
  for (uint16_t i = 0; i < 1024; i++)
  {
    while(!imu.gyroDataReady()) {}
    imu.readGyro();

    total += imu.g.z;
  }
  ledYellow(0); //Slår av gul LED
  gyroOffset = total / 1024;

  turnSensorReset();
  //Kjør når bruker presser knapp B
  while (!buttonB.getSingleDebouncedRelease())
  {
    turnSensorUpdate();
  }
}
